package org.laboratorio3;

/**
 * @author Antonio J. Nebro
 */
public interface AdvertiserDatabase {
  boolean findAdviser(String adviserName);
}
