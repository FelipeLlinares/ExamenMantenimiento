package org.laboratorio3;

public class FullBoardException extends RuntimeException {}